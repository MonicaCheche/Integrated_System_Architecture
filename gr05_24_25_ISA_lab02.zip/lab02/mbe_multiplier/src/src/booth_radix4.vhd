library ieee;
use ieee.std_logic_1164.all;

entity booth_radix4 is  
  port (
    X2 : in std_logic;
    X1 : in std_logic;
    X0 : in std_logic;
    Y: out std_logic_vector(1 downto 0));
end entity booth_radix4;

architecture beh of booth_radix4 is

signal Y1, Y0: std_logic;

begin
	Y1<=(X2 and (not(X1)) and (not(X0)))or ((not(X2) and X1 and X0));
 
	Y0<=(not(X1) and X0)or  (X1 and not(X0));
	
	Y<=Y1&Y0;
end beh;
