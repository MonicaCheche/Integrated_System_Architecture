library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity dadda_tree is --motliplicatore dadda

port ( 
	operand1, operand2, operand3, operand4, operand5: in std_logic_vector(8 downto 0);
	sign_operand1, sign_operand2, sign_operand3, sign_operand4: in std_logic;
	dadda_out : out std_logic_vector (15 downto 0));
end dadda_tree;

architecture behaviour of dadda_tree is

component half_adder is

port ( in1,in2 : in std_logic;
       s,c_out : out std_logic);
end component;

component full_adder is
port ( in1,in2,c_in : in std_logic;
       s,c_out : out std_logic);
end component;

signal pp1: std_logic_vector(11 downto 0);
signal pp2, pp3: std_logic_vector(10 downto 0);
signal pp4: std_logic_vector(9 downto 0);
signal pp5: std_logic_vector(8 downto 0);


signal s_fa1,s_fa2,s_fa3,s_fa4,s_fa5,s_fa6,s_fa7,s_fa8,s_fa9,s_fa10,s_fa11,s_fa12,s_fa13,s_fa14,s_fa15,s_fa16,s_fa17,s_fa18,s_fa19,s_fa20,s_fa21,s_fa22,s_fa23,s_fa24,s_fa25,s_fa26,s_fa27,s_fa28,s_fa29,s_fa30,s_fa31,s_fa32,s_fa33,s_fa34,s_fa35,s_fa36,s_fa37,s_fa38,s_fa39,s_fa40,s_ha1,s_ha2,s_ha3,s_ha4,s_ha5,s_ha6,s_ha7,s_ha8, s_ha9, s_ha10 :std_logic;
signal c_fa1,c_fa2,c_fa3,c_fa4,c_fa5,c_fa6,c_fa7,c_fa8,c_fa9,c_fa10,c_fa11,c_fa12,c_fa13,c_fa14,c_fa15,c_fa16,c_fa17,c_fa18,c_fa19,c_fa20,c_fa21,c_fa22,c_fa23,c_fa24,c_fa25,c_fa26,c_fa27,c_fa28,c_fa29,c_fa30,c_fa31,c_fa32,c_fa33,c_fa34,c_fa35,c_fa36,c_fa37,c_fa38,c_fa39,c_fa40,c_ha1,c_ha2,c_ha3,c_ha4,c_ha5,c_ha6,c_ha7,c_ha8, c_ha9, c_ha10:std_logic;
signal not_sign_operand4 : std_logic;


begin

pp1 <= not sign_operand1 & sign_operand1 & sign_operand1 & operand1(8 downto 0);
pp2 <= '1' & not sign_operand2 & operand2(8 downto 0);
pp3 <= '1' & not sign_operand3 & operand3(8 downto 0);
pp4 <= not sign_operand4 & operand4(8 downto 0);
pp5 <= operand5(8 downto 0);

not_sign_operand4 <= not sign_operand4;



--first layer 5to4 ha and fa.
ha1: half_adder port map(pp1(6),pp2(4),s_ha1,c_ha1);
ha2: half_adder port map(pp1(7),pp2(5),s_ha2,c_ha2);
ha3: half_adder port map(pp2(10),pp3(8),s_ha3,c_ha3);

fa1: full_adder port map(pp1(8),pp2(6),pp3(4),s_fa1,c_fa1);
fa2: full_adder port map(pp1(9),pp2(7),pp3(5),s_fa2,c_fa2);
fa3: full_adder port map(pp1(10),pp2(8),pp3(6),s_fa3,c_fa3);
fa4: full_adder port map(pp1(11),pp2(9),pp3(7),s_fa4,c_fa4);


--second layer 4to3
ha4: half_adder port map(pp1(4),pp2(2),s_ha4,c_ha4);
ha5: half_adder port map(pp1(5),pp2(3),s_ha5,c_ha5);
ha6: half_adder port map(pp3(10),pp4(8),s_ha6,c_ha6);

fa5: full_adder port map(s_ha1,pp3(2),pp4(0),s_fa5,c_fa5);
fa6: full_adder port map(s_ha2,c_ha1,pp3(3),s_fa6,c_fa6);
fa7: full_adder port map(s_fa1,c_ha2,pp4(2),s_fa7,c_fa7);
fa8: full_adder port map(s_fa2,c_fa1,pp4(3),s_fa8,c_fa8);
fa9: full_adder port map(s_fa3,c_fa2,pp4(4),s_fa9,c_fa9);
fa10: full_adder port map(s_fa4,c_fa3,pp4(5),s_fa10,c_fa10);
fa11: full_adder port map(s_ha3,c_fa4,pp4(6),s_fa11,c_fa11);
fa12: full_adder port map(c_ha3,pp3(9),pp4(7),s_fa12,c_fa12);



--third layer 3to2
ha7: half_adder port map(pp1(2),pp2(0),s_ha7,c_ha7);
ha8: half_adder port map(pp1(3),pp2(1),s_ha8,c_ha8);
fa13: full_adder port map(s_ha4,pp3(0),sign_operand3 ,s_fa13,c_fa13);
fa14: full_adder port map(s_ha5,c_ha4,pp3(1),s_fa14,c_fa14);
fa15: full_adder port map(s_fa5,c_ha5,sign_operand4,s_fa15,c_fa15);
fa16: full_adder port map(s_fa6,c_fa5,pp4(1),s_fa16,c_fa16);
fa17: full_adder port map(s_fa7,c_fa6,pp5(0),s_fa17,c_fa17);
fa18: full_adder port map(s_fa8,c_fa7,pp5(1),s_fa18,c_fa18);
fa19: full_adder port map(s_fa9,c_fa8,pp5(2),s_fa19,c_fa19);
fa20: full_adder port map(s_fa10,c_fa9,pp5(3),s_fa20,c_fa20);
fa21: full_adder port map(s_fa11,c_fa10,pp5(4),s_fa21,c_fa21);
fa22: full_adder port map(s_fa12,c_fa11,pp5(5),s_fa22,c_fa22);
fa23: full_adder port map(s_ha6,c_fa12,pp5(6),s_fa23,c_fa23);
fa24: full_adder port map(c_ha6,not_sign_operand4,pp5(7),s_fa24,c_fa24);






-- two operand adder  RCA
ha9: half_adder port map(pp1(0),sign_operand1,s_ha9,c_ha9);
fa25: full_adder port map(pp1(1),'0',c_ha9,s_fa25,c_fa25);
fa26: full_adder port map(s_ha7,sign_operand2,c_fa25,s_fa26,c_fa26);
fa27: full_adder port map(s_ha8,c_fa26,c_ha7,s_fa27,c_fa27);
fa28: full_adder port map(s_fa13,c_fa27,c_ha8,s_fa28,c_fa28);
fa29: full_adder port map(s_fa14,c_fa28,c_fa13,s_fa29,c_fa29);
fa30: full_adder port map(s_fa15,c_fa29,c_fa14,s_fa30,c_fa30);
fa31: full_adder port map(s_fa16,c_fa30,c_fa15,s_fa31,c_fa31);
fa32: full_adder port map(s_fa17,c_fa31,c_fa16,s_fa32,c_fa32);
fa33: full_adder port map(s_fa18,c_fa32,c_fa17,s_fa33,c_fa33);
fa34: full_adder port map(s_fa19,c_fa33,c_fa18,s_fa34,c_fa34);
fa35: full_adder port map(s_fa20,c_fa34,c_fa19,s_fa35,c_fa35);
fa36: full_adder port map(s_fa21,c_fa35,c_fa20,s_fa36,c_fa36);
fa37: full_adder port map(s_fa22,c_fa36,c_fa21,s_fa37,c_fa37);
fa38: full_adder port map(s_fa23,c_fa37,c_fa22,s_fa38,c_fa38);
fa39: full_adder port map(s_fa24,c_fa38,c_fa23,s_fa39,c_fa39);
ha10: full_adder port map(c_fa24,c_fa39,s_ha10,c_ha10);

dadda_out<= s_fa39 & s_fa38 & s_fa37 & s_fa36 & s_fa35 & s_fa34 & s_fa33 & s_fa32 & s_fa31 & s_fa30 & s_fa29 & s_fa28 & s_fa27 & s_fa26 & s_fa25 & s_ha9;





--mid_1<= '0' &'1' &pp4(9) &s_ha6 &s_fa16 &s_fa15 &s_fa14 & s_fa13 &s_fa12 &s_fa11 &s_fa10 &s_fa9 &s_fa8 &s_fa7 &s_ha5 &s_ha4 &pp1(1)& pp1(0);
--mid_1<= '0' &pp4(8) &s_fa16 &s_fa15 &s_fa14 & s_fa13 &s_fa12 &s_fa11 &s_fa10 &s_fa9 &s_fa8 &s_fa7 &s_ha5 &s_ha4 &pp1(1)& pp1(0);
--mid_2<= '0' &'0' &c_ha6 &c_fa16 &c_fa15 &c_fa14 &c_fa13 &c_fa12 &c_fa11 &c_fa10 &c_fa9 &c_fa8 &c_fa7 &c_ha5 &c_ha4 &not pp2(9) &'0' &not pp1(11);
--mid_2<= '0' &c_fa16 &c_fa15 &c_fa14 &c_fa13 &c_fa12 &c_fa11 &c_fa10 &c_fa9 &c_fa8 &c_fa7 &c_ha5 &c_ha4 &not pp2(9) &'0' &not pp1(11);
--dadda_out<=std_logic_vector(Unsigned(mid_1) + Unsigned(mid_2));



end behaviour;
