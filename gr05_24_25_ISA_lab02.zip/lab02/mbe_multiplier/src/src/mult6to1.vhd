library ieee;
use ieee.std_logic_1164.all;

entity mult6to1 is
	generic(N:integer);
	port(
	A_input: in std_logic_vector((N-1) downto 0);
	X_msb: in std_logic;
	Y: in std_logic_vector(1 downto 0);
	operand_out: out std_logic_vector(N downto 0));
end mult6to1;

architecture behavioral of mult6to1 is

signal zero_9bit_positive, zero_9bit_negative, one_A, twe_A, twe_A_inv, one_A_inv: std_logic_vector(N downto 0);
signal sel3bit: std_logic_vector(2 downto 0);

begin
zero_9bit_positive<= (others=>'0');
one_A<= '0'&A_input;
twe_A<= A_input&'0';
twe_A_inv<= not(A_input&'0');
one_A_inv<= '1'&not(A_input);
sel3bit<= X_msb&Y ;
zero_9bit_negative<= (others=>'1');

mux : process(zero_9bit_positive, zero_9bit_negative, one_A, twe_A, twe_A_inv, one_A_inv, sel3bit)
begin
  case sel3bit is
    when "000" => operand_out <= zero_9bit_positive;
    when "001" => operand_out <= one_A ;
    when "010" => operand_out <= twe_A ;
    when "110" => operand_out <= twe_A_inv;
	when "101" => operand_out <= one_A_inv;
	when "100" => operand_out <= zero_9bit_negative;
	
	when others => operand_out<=(others=>'1');
  end case;
end process mux;	




end behavioral;