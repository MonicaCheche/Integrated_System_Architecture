library ieee;
use ieee.std_logic_1164.all;


entity half_adder is 

port ( in1,in2 : in std_logic;
       s,c_out : out std_logic);
end half_adder;

architecture beh of half_adder is

begin

s<=in1 xor in2;
c_out<= in1 and in2;


end beh;
