library ieee;
use ieee.std_logic_1164.all;


entity full_adder is 

port ( in1,in2,c_in : in std_logic;
       s,c_out : out std_logic);
end full_adder;

architecture beh of full_adder is

begin

s<=in1 xor in2 xor c_in;
c_out<= (in1 and in2) or (in1 and c_in) or (in2 and c_in);


end beh;
