module topmultiplier (
	input logic [7:0] mantissa_a,
	input logic [7:0] mantissa_b,
	output logic [15:0] product 
);


logic mux1_o[8:0];
logic mux2_o[8:0];
logic mux3_o[8:0];
logic mux4_o[8:0];
logic mux5_o[8:0];

logic sign_1;
logic sign_2;
logic sign_3;
logic sign_4;


//full_booth
full_booth BE (
			  .mantissa_a(mantissa_a), 
			  .mantissa_b(mantissa_b),
			  .out_mux1(mux1_o),
			  .out_mux2(mux2_o),
			  .out_mux3(mux3_o),
			  .out_mux4(mux4_o),
			  .out_mux5(mux5_o),
			  .sign_operand_1(sign_1),
			  .sign_operand_2(sign_2),
			  .sign_operand_3(sign_3),
			  .sign_operand_4(sign_4));


dadda_tree DE(.operand1(mux1_o),
			  .operand2(mux2_o),
			  .operand3(mux3_o),
			  .operand4(mux4_o),
			  .operand5(mux5_o),
			  .sign_operand1(sign_1),
			  .sign_operand2(sign_2),
			  .sign_operand3(sign_3),
			  .sign_operand4(sign_4),
			  .dadda_out(product));
			  
endmodule


