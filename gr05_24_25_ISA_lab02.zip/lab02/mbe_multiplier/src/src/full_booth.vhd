library ieee;
use ieee.std_logic_1164.all;

entity full_booth is  

	--generic(n:integer); --n=8;
	port (
	mantissa_a, mantissa_b: in std_logic_vector(7 downto 0);
	out_mux1, out_mux2, out_mux3, out_mux4, out_mux5: out std_logic_vector(8 downto 0);
	sign_operand_1, sign_operand_2, sign_operand_3, sign_operand_4: out std_logic);
	end full_booth;
	
architecture beh of full_booth is 
	
	
component booth_radix4 is
	port(
	X2 : in std_logic;
    X1 : in std_logic;
    X0 : in std_logic;
    Y: out std_logic_vector(1 downto 0));
	end component;
	
component mult6to1 is
	generic(N:integer);
	port(
	A_input: in std_logic_vector((N-1) downto 0);
	X_msb: in std_logic;
	Y: in std_logic_vector(1 downto 0);
	operand_out: out std_logic_vector(N downto 0));
end component;

signal y_mux1, y_mux2, y_mux3, y_mux4, y_mux5: std_logic_vector(1 downto 0); 

begin
	MBE1: booth_radix4
		port map(X2=>mantissa_b(1), X1=>mantissa_b(0), X0=>'0', Y=>y_mux1);
	
	MBE2: booth_radix4
		port map(X2=>mantissa_b(3), X1=>mantissa_b(2), X0=>mantissa_b(1), Y=>y_mux2);
	
	MBE3: booth_radix4
		port map(X2=>mantissa_b(5), X1=>mantissa_b(4), X0=>mantissa_b(3), Y=>y_mux3);
	
	MBE4: booth_radix4
		port map(X2=>mantissa_b(7), X1=>mantissa_b(6), X0=>mantissa_b(5), Y=>y_mux4);
	
	MBE5: booth_radix4
		port map(X2=>'0', X1=>'0', X0=>mantissa_b(7), Y=>y_mux5);
	
	
	MUX1: mult6to1
	generic map(N=>8)
	port map(A_input=>mantissa_a, X_msb=>mantissa_b(1), Y=>y_mux1, operand_out=>out_mux1);
	
	MUX2: mult6to1
	generic map(N=>8)
	port map(A_input=>mantissa_a, X_msb=>mantissa_b(3), Y=>y_mux2, operand_out=>out_mux2);
	
	MUX3: mult6to1
	generic map(N=>8)
	port map(A_input=>mantissa_a, X_msb=>mantissa_b(5), Y=>y_mux3, operand_out=>out_mux3);
	
	MUX4: mult6to1
	generic map(N=>8)
	port map(A_input=>mantissa_a, X_msb=>mantissa_b(7), Y=>y_mux4, operand_out=>out_mux4);
	
	
	MUX5: mult6to1
	generic map(N=>8)
	port map(A_input=>mantissa_a, X_msb=>'0', Y=>y_mux5, operand_out=>out_mux5);
	
	sign_operand_1<=mantissa_b(1);
	sign_operand_2<=mantissa_b(3);
	sign_operand_3<=mantissa_b(5);
	sign_operand_4<=mantissa_b(7);
	

end beh;
