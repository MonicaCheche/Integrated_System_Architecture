
module tb_topmultiplier;
	
    reg [7:0] mantissa_a; // Input signal A
    reg [7:0] mantissa_b; // Input signal B
    wire [15:0] product;
    


initial begin

	#10
     mantissa_a = 8'b01101010; // 106 in binary
     mantissa_b = 8'b01110100; // 116 in binary

	
	#20

     mantissa_a = 8'b00000100; // 132 in binary
     mantissa_b = 8'b00111000; // 184
 	

	end 


// Instantiate the multiplier module
    topmultiplier uut (
        .mantissa_a(mantissa_a), // Map signal A
        .mantissa_b(mantissa_b),  // Map signal B
		.product(product));


    // Assign static binary values
	


endmodule 
