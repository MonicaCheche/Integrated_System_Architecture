# Project Overview

This project contains two main modules:

1. fp16_synthesis
This module is responsible for the 16-bit floating-point(BFLOAT) operations. It includes the following subdirectories:

	- comand_scripts: 	  Contains scripts for executing commands related to 1-simulation 2-synthesis 3-netlist simulation 				          of 10 BFLOATsamples we give to cvfpu lite project.
	- scr: 			  include src of cvfpu lite project and tb files to test it.
	- netlist_generated_file: Stores fpnewtop vhdl files generated in netlist, after the synthesis with 1-compile 2-                                  compile&retiming 3-compile_ultra 4-compile+csa&retiming 5-compile+PPARCH&retiming .
	- report: 		  Contains timing and area reports for all processes, besides resources for the CSA and PPARCH 				  processes

2. MBA_multiplier
This module focuses on the implementation of a Modified Booth Encoding (MBE) multiplier. The following subdirectories are included:

	- src: 			  Contains the source code files for the MBA_multiplier, also tb for testing it.
	- report: 		  Includes area, timing and rsource reports of the MBA_multiplier synthesis.
	- comand:		  Contains commands for executing simulation, synthesis with compile_ultra , netlist simulation  			                  related to this module, finally simmulation of the fma.
	- netlist_generated_file: Stores the fpnewtop vhdl file generated in the netlist for the MBE multiplier.
